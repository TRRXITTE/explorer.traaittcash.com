<?php

// used for API calls change it to your own Qwertycoin RPC node
// daemon:port 8197 is the default RPC Port
$apiNode = 'https://europe-west.traaitt.com';
