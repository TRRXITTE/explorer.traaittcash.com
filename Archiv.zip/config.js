var api = 'https://explorer.traaittcash.com';
var api_blockexplorer = 'https://europe-west.traaitt.com';
var apiList = [
	'https://europe-west.traaitt.com'
];
var blockTargetInterval = 144;
var coinUnits = 100000000;
var symbol = 'TCH';
var refreshDelay = 15000;
// pools stats by MainCoins
var poolsStat =
	[
		["traaittCASH offical","https://traaittsupply.cash:8117/stats"],
		["Cryptonote.Club","http://tch.cryptonote.club:8117/stats"]
    ];
var nodesStat =
	[
		['http://us-west.traaitt.com:14486'],
		['http://europe-west.traaitt.com:14486'],
		['http://asia-southeast.traaitt.com:14486']
    ];