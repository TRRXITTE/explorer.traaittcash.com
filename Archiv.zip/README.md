

**traaittCASH is a decentralized peer-to-peer protocol for safe payments worldwide.**

### traaittCASH Blockchain Explorer

Block explorer for traaittCASH CryptoNote based cryptocurrency based on the Karbowanec transaction explorer

#### Installation

1) It takes data from daemon traaittCASHd. It should be accessible from the Internet. Run qwertycoind with open port as follows:
```bash
./traaittCASHd --enable-cors=* --rpc-bind-ip=0.0.0.0 --rpc-bind-port=8197
```
2) Just upload to your website and change 'api' variable in config.js to point to your daemon. Also change the '$apiNode=' variable in /api/index.php to point the API urls to your daemon.

## Donate

```
XTCASH: cashKdCEq5U7W2QDS5ffMETf1smoKLBm3C1GMYvPdEVUU9LKr1uDFrLNPkmfKgzcTcB4ASsypziCeVQ5iqkzC7fZ1pDDLSxgZF
```
```
BTC: 3GVrutx2mdn7Gr63oVL83htgLBfMzXHJfT
```
```
ETH: 0xec2e86bc5b952dd5415270a123ec1eb89e1226ba
```

#### Thanks

Cryptonote Developers, Bytecoin Developers, Monero Developers, Karbo, Qwertycoin Community
